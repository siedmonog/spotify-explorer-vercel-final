import { useState, useEffect } from 'react';
import { SpotifyService } from '../../services/spotifyService';
import { useAuth } from '../../context/AuthContext';

/**
 * Interface para gênero musical
 */
interface Genre {
  name: string;
}

/**
 * Interface para categorias de gêneros
 */
interface CategorizedGenres {
  [category: string]: string[];
}

/**
 * Componente de listagem de gêneros musicais
 */
const GenreList = ({ onSelectGenre }: { onSelectGenre: (genre: string) => void }) => {
  const { isAuthenticated } = useAuth();
  const [genres, setGenres] = useState<string[]>([]);
  const [categorizedGenres, setCategorizedGenres] = useState<CategorizedGenres>({});
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  // Carregar gêneros ao montar o componente
  useEffect(() => {
    if (isAuthenticated) {
      fetchGenres();
    }
  }, [isAuthenticated]);

  // Função para buscar gêneros
  const fetchGenres = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.getGenres();
      setGenres(data.genres);
      setCategorizedGenres(data.categorized);
    } catch (err) {
      setError('Falha ao carregar gêneros musicais.');
      console.error('Erro ao buscar gêneros:', err);
    } finally {
      setLoading(false);
    }
  };

  // Função para renderizar gêneros
  const renderGenres = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-green-500"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      );
    }

    if (genres.length === 0) {
      return (
        <div className="p-4 text-gray-600 dark:text-gray-400 text-center">
          Nenhum gênero musical encontrado.
        </div>
      );
    }

    // Determinar quais gêneros mostrar com base na categoria ativa
    const genresToShow = activeCategory === 'all' 
      ? genres 
      : categorizedGenres[activeCategory] || [];

    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {genresToShow.map((genre) => (
          <div
            key={genre}
            onClick={() => onSelectGenre(genre)}
            className="p-3 bg-white dark:bg-gray-700 rounded-lg shadow-sm cursor-pointer hover:shadow-md transition-shadow duration-200 text-center border border-gray-200 dark:border-gray-600"
          >
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
              {genre.replace(/-/g, ' ')}
            </span>
          </div>
        ))}
      </div>
    );
  };

  // Renderizar categorias
  const renderCategories = () => {
    const categories = ['all', ...Object.keys(categorizedGenres)];
    
    return (
      <div className="flex flex-wrap gap-2 mb-6">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-3 py-1 rounded-full text-sm font-medium ${
              activeCategory === category
                ? 'bg-green-600 text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            {category === 'all' ? 'Todos' : category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="w-full">
      <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
        Gêneros Musicais
      </h2>
      
      {Object.keys(categorizedGenres).length > 0 && renderCategories()}
      
      {renderGenres()}
    </div>
  );
};

export default GenreList;
