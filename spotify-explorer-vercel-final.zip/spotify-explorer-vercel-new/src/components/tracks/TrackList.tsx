import { useState, useEffect } from 'react';
import { SpotifyService, FilterOptions } from '../../services/spotifyService';
import { useAuth } from '../../context/AuthContext';

/**
 * Interface para música
 */
interface Track {
  id: string;
  name: string;
  album: {
    id: string;
    name: string;
    images: Array<{url: string}>;
  };
  artists: Array<{id: string; name: string}>;
  duration_ms: number;
  popularity: number;
  audio_features?: {
    tempo: number;
    energy: number;
    valence: number;
    danceability: number;
    acousticness: number;
    instrumentalness: number;
  };
}

/**
 * Interface para opções de ordenação
 */
interface SortOption {
  label: string;
  value: keyof Track | 'audio_features.tempo' | 'audio_features.energy' | 'audio_features.valence' | 'audio_features.danceability';
  direction: 'asc' | 'desc';
}

/**
 * Componente de listagem de músicas
 */
const TrackList = ({ 
  albumId,
  genreFilter,
  onSelectTrack 
}: { 
  albumId?: string;
  genreFilter?: string;
  onSelectTrack: (track: Track) => void 
}) => {
  const { isAuthenticated } = useAuth();
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [albumName, setAlbumName] = useState<string>('');
  const [sortOption, setSortOption] = useState<SortOption>({
    label: 'Nome (A-Z)',
    value: 'name',
    direction: 'asc'
  });

  // Opções de ordenação disponíveis
  const sortOptions: SortOption[] = [
    { label: 'Nome (A-Z)', value: 'name', direction: 'asc' },
    { label: 'Nome (Z-A)', value: 'name', direction: 'desc' },
    { label: 'Popularidade (Maior)', value: 'popularity', direction: 'desc' },
    { label: 'Popularidade (Menor)', value: 'popularity', direction: 'asc' },
    { label: 'Duração (Maior)', value: 'duration_ms', direction: 'desc' },
    { label: 'Duração (Menor)', value: 'duration_ms', direction: 'asc' },
    { label: 'BPM (Maior)', value: 'audio_features.tempo', direction: 'desc' },
    { label: 'BPM (Menor)', value: 'audio_features.tempo', direction: 'asc' },
    { label: 'Energia (Maior)', value: 'audio_features.energy', direction: 'desc' },
    { label: 'Energia (Menor)', value: 'audio_features.energy', direction: 'asc' },
    { label: 'Felicidade (Maior)', value: 'audio_features.valence', direction: 'desc' },
    { label: 'Felicidade (Menor)', value: 'audio_features.valence', direction: 'asc' },
    { label: 'Dançabilidade (Maior)', value: 'audio_features.danceability', direction: 'desc' },
    { label: 'Dançabilidade (Menor)', value: 'audio_features.danceability', direction: 'asc' },
  ];

  // Carregar músicas quando o ID do álbum ou gênero mudar
  useEffect(() => {
    if (isAuthenticated) {
      if (albumId) {
        fetchTracksByAlbum(albumId);
      } else if (genreFilter) {
        fetchTracksByGenre(genreFilter);
      }
    }
  }, [isAuthenticated, albumId, genreFilter]);

  // Função para buscar músicas por álbum
  const fetchTracksByAlbum = async (id: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.getAlbumTracks(id);
      setTracks(data.tracks);
      
      // Definir nome do álbum a partir da primeira faixa
      if (data.tracks.length > 0) {
        setAlbumName(data.tracks[0].album.name);
      }
    } catch (err) {
      setError('Falha ao carregar músicas.');
      console.error('Erro ao buscar músicas:', err);
    } finally {
      setLoading(false);
    }
  };

  // Função para buscar músicas por gênero
  const fetchTracksByGenre = async (genre: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.getRecommendationsByGenre(genre);
      setTracks(data.tracks);
      setAlbumName(''); // Limpar nome do álbum
    } catch (err) {
      setError('Falha ao carregar músicas.');
      console.error('Erro ao buscar músicas:', err);
    } finally {
      setLoading(false);
    }
  };

  // Formatar duração da música
  const formatDuration = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Ordenar músicas
  const sortTracks = (tracks: Track[]) => {
    return [...tracks].sort((a, b) => {
      let valueA, valueB;
      
      // Lidar com propriedades aninhadas (audio_features)
      if (sortOption.value.includes('.')) {
        const [parent, child] = sortOption.value.split('.');
        valueA = a[parent as keyof Track]?.[child as keyof typeof a.audio_features];
        valueB = b[parent as keyof Track]?.[child as keyof typeof b.audio_features];
      } else {
        valueA = a[sortOption.value as keyof Track];
        valueB = b[sortOption.value as keyof Track];
      }
      
      // Lidar com valores indefinidos
      if (valueA === undefined) return 1;
      if (valueB === undefined) return -1;
      
      // Ordenação de strings
      if (typeof valueA === 'string' && typeof valueB === 'string') {
        return sortOption.direction === 'asc'
          ? valueA.localeCompare(valueB)
          : valueB.localeCompare(valueA);
      }
      
      // Ordenação numérica
      return sortOption.direction === 'asc'
        ? Number(valueA) - Number(valueB)
        : Number(valueB) - Number(valueA);
    });
  };

  // Renderizar músicas
  const renderTracks = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-green-500"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      );
    }

    if (tracks.length === 0) {
      return (
        <div className="p-4 text-gray-600 dark:text-gray-400 text-center">
          Nenhuma música encontrada.
        </div>
      );
    }

    const sortedTracks = sortTracks(tracks);

    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Música
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Artista
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Álbum
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Duração
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Popularidade
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {sortedTracks.map((track) => (
              <tr 
                key={track.id}
                onClick={() => onSelectTrack(track)}
                className="hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="h-10 w-10 flex-shrink-0">
                      {track.album.images && track.album.images[0] ? (
                        <img className="h-10 w-10 rounded-sm" src={track.album.images[0].url} alt="" />
                      ) : (
                        <div className="h-10 w-10 rounded-sm bg-gray-300 dark:bg-gray-600 flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                          </svg>
                        </div>
                      )}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {track.name}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {track.artists.map(artist => artist.name).join(', ')}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white truncate max-w-xs">
                    {track.album.name}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {formatDuration(track.duration_ms)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                      <div 
                        className="bg-green-600 h-2.5 rounded-full" 
                        style={{ width: `${track.popularity}%` }}
                      ></div>
                    </div>
                    <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                      {track.popularity}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-2 sm:mb-0">
          {albumName ? `Músicas de ${albumName}` : genreFilter ? `Músicas: ${genreFilter.replace(/-/g, ' ')}` : 'Músicas'}
        </h2>
        
        <div className="w-full sm:w-auto">
          <select
            value={sortOptions.findIndex(option => 
              option.value === sortOption.value && option.direction === sortOption.direction
            )}
            onChange={(e) => setSortOption(sortOptions[parseInt(e.target.value)])}
            className="block w-full sm:w-auto px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 text-sm"
          >
            {sortOptions.map((option, index) => (
              <option key={index} value={index}>
                Ordenar por: {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {renderTracks()}
    </div>
  );
};

export default TrackList;
