import { useState, useEffect } from 'react';
import { SpotifyService, FilterOptions } from '../../services/spotifyService';
import { useAuth } from '../../context/AuthContext';
import FilterPanel from '../filters/FilterPanel';

/**
 * Interface para visualização de atributos de áudio
 */
interface AudioFeatures {
  tempo: number;
  energy: number;
  valence: number;
  danceability: number;
  acousticness: number;
  instrumentalness: number;
}

/**
 * Interface para música
 */
interface Track {
  id: string;
  name: string;
  album: {
    id: string;
    name: string;
    images: Array<{url: string}>;
  };
  artists: Array<{id: string; name: string}>;
  duration_ms: number;
  popularity: number;
  audio_features?: AudioFeatures;
}

/**
 * Componente para visualização detalhada de uma música
 */
const TrackDetails = ({ track }: { track: Track }) => {
  const { isAuthenticated } = useAuth();
  const [audioFeatures, setAudioFeatures] = useState<AudioFeatures | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Carregar características de áudio quando o ID da música mudar
  useEffect(() => {
    if (isAuthenticated && track && !track.audio_features) {
      fetchAudioFeatures(track.id);
    } else if (track && track.audio_features) {
      setAudioFeatures(track.audio_features);
    }
  }, [isAuthenticated, track]);

  // Função para buscar características de áudio
  const fetchAudioFeatures = async (trackId: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.getTrack(trackId);
      setAudioFeatures(data.audio_features);
    } catch (err) {
      setError('Falha ao carregar características de áudio.');
      console.error('Erro ao buscar características de áudio:', err);
    } finally {
      setLoading(false);
    }
  };

  // Formatar duração da música
  const formatDuration = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Renderizar barra de atributo
  const renderAttributeBar = (label: string, value: number, color: string) => {
    // Normalizar valor para porcentagem (0-100)
    const percentage = Math.round(value * 100);
    
    return (
      <div className="mb-3">
        <div className="flex justify-between items-center mb-1">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
          <span className="text-sm text-gray-600 dark:text-gray-400">{percentage}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
          <div 
            className={`h-2.5 rounded-full ${color}`} 
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex flex-col md:flex-row">
          {/* Capa do álbum */}
          <div className="w-full md:w-1/3 mb-4 md:mb-0 md:mr-6">
            {track.album.images && track.album.images[0] ? (
              <img
                src={track.album.images[0].url}
                alt={track.album.name}
                className="w-full h-auto rounded-lg shadow-md"
              />
            ) : (
              <div className="w-full h-64 bg-gray-300 dark:bg-gray-700 rounded-lg shadow-md flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                </svg>
              </div>
            )}
          </div>
          
          {/* Informações da música */}
          <div className="w-full md:w-2/3">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{track.name}</h1>
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-4">
              {track.artists.map(artist => artist.name).join(', ')}
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Álbum</p>
                <p className="text-base text-gray-800 dark:text-gray-200">{track.album.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Duração</p>
                <p className="text-base text-gray-800 dark:text-gray-200">{formatDuration(track.duration_ms)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Popularidade</p>
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mr-2">
                    <div 
                      className="bg-green-600 h-2.5 rounded-full" 
                      style={{ width: `${track.popularity}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {track.popularity}%
                  </span>
                </div>
              </div>
              {audioFeatures && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">BPM (Tempo)</p>
                  <p className="text-base text-gray-800 dark:text-gray-200">{Math.round(audioFeatures.tempo)}</p>
                </div>
              )}
            </div>
            
            {/* Características de áudio */}
            {loading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-green-500"></div>
              </div>
            ) : error ? (
              <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                {error}
              </div>
            ) : audioFeatures ? (
              <div>
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Características de Áudio</h3>
                {renderAttributeBar('Energia', audioFeatures.energy, 'bg-red-500')}
                {renderAttributeBar('Felicidade', audioFeatures.valence, 'bg-yellow-500')}
                {renderAttributeBar('Dançabilidade', audioFeatures.danceability, 'bg-purple-500')}
                {renderAttributeBar('Acústica', audioFeatures.acousticness, 'bg-blue-500')}
                {renderAttributeBar('Instrumental', audioFeatures.instrumentalness, 'bg-indigo-500')}
              </div>
            ) : (
              <div className="p-4 text-gray-600 dark:text-gray-400 text-center">
                Características de áudio não disponíveis.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackDetails;
