import { useState, useEffect } from 'react';
import { SpotifyService } from '../../services/spotifyService';
import { useAuth } from '../../context/AuthContext';

/**
 * Interface para álbum
 */
interface Album {
  id: string;
  name: string;
  images: Array<{url: string}>;
  release_date: string;
  total_tracks: number;
  artists: Array<{id: string; name: string}>;
}

/**
 * Componente de listagem de álbuns
 */
const AlbumList = ({ 
  artistId, 
  onSelectAlbum 
}: { 
  artistId?: string; 
  onSelectAlbum: (album: Album) => void 
}) => {
  const { isAuthenticated } = useAuth();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [artistName, setArtistName] = useState<string>('');

  // Carregar álbuns quando o ID do artista mudar
  useEffect(() => {
    if (isAuthenticated && artistId) {
      fetchAlbumsByArtist(artistId);
    }
  }, [isAuthenticated, artistId]);

  // Função para buscar álbuns por artista
  const fetchAlbumsByArtist = async (id: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.getArtistAlbums(id);
      setAlbums(data.items);
      
      // Definir nome do artista a partir do primeiro álbum
      if (data.items.length > 0 && data.items[0].artists.length > 0) {
        const artist = data.items[0].artists.find(a => a.id === id);
        if (artist) {
          setArtistName(artist.name);
        }
      }
    } catch (err) {
      setError('Falha ao carregar álbuns.');
      console.error('Erro ao buscar álbuns:', err);
    } finally {
      setLoading(false);
    }
  };

  // Formatar data de lançamento
  const formatReleaseDate = (date: string) => {
    if (!date) return '';
    
    // Verificar formato da data (YYYY ou YYYY-MM-DD)
    if (date.length === 4) return date; // Apenas ano
    
    try {
      return new Date(date).toLocaleDateString('pt-BR');
    } catch (e) {
      return date;
    }
  };

  // Renderizar álbuns
  const renderAlbums = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-green-500"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      );
    }

    if (albums.length === 0) {
      return (
        <div className="p-4 text-gray-600 dark:text-gray-400 text-center">
          Nenhum álbum encontrado.
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {albums.map((album) => (
          <div
            key={album.id}
            onClick={() => onSelectAlbum(album)}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-200"
          >
            <div className="h-48 bg-gray-200 dark:bg-gray-700 relative">
              {album.images && album.images[0] ? (
                <img
                  src={album.images[0].url}
                  alt={album.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-300 dark:bg-gray-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                  </svg>
                </div>
              )}
            </div>
            <div className="p-4">
              <h3 className="font-bold text-gray-800 dark:text-white truncate">{album.name}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                {album.artists.map(artist => artist.name).join(', ')}
              </p>
              <div className="flex justify-between items-center mt-2 text-sm text-gray-500 dark:text-gray-400">
                <span>{formatReleaseDate(album.release_date)}</span>
                <span>{album.total_tracks} faixas</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="w-full">
      <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
        {artistName ? `Álbuns de ${artistName}` : 'Álbuns'}
      </h2>
      
      {renderAlbums()}
    </div>
  );
};

export default AlbumList;
