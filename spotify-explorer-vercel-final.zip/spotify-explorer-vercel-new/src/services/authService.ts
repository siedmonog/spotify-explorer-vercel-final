/**
 * Serviço para gerenciar a autenticação com o Spotify
 */
import axios from 'axios';

// URL base da API (ajustar para produção/desenvolvimento)
const API_URL = 'http://localhost:3001/api';

/**
 * Classe de serviço para autenticação
 */
export class AuthService {
  /**
   * Obtém token de acesso usando Client Credentials
   * @param clientId - Client ID do Spotify
   * @param clientSecret - Client Secret do Spotify
   * @returns Token de acesso
   */
  static async getToken(clientId: string, clientSecret: string): Promise<string> {
    try {
      const response = await axios.post(`${API_URL}/auth/token`, {
        clientId,
        clientSecret
      });
      
      return response.data.data.token;
    } catch (error) {
      console.error('Erro ao obter token:', error);
      throw new Error('Falha na autenticação. Verifique suas credenciais.');
    }
  }

  /**
   * Verifica se o token é válido
   * @param token - Token a ser verificado
   * @returns Verdadeiro se o token for válido
   */
  static async verifyToken(token: string): Promise<boolean> {
    try {
      await axios.post(`${API_URL}/auth/verify`, { token });
      return true;
    } catch (error) {
      console.error('Token inválido:', error);
      return false;
    }
  }

  /**
   * Salva o token no armazenamento local
   * @param token - Token a ser salvo
   */
  static saveToken(token: string): void {
    localStorage.setItem('spotify_token', token);
  }

  /**
   * Recupera o token do armazenamento local
   * @returns Token salvo ou null se não existir
   */
  static getStoredToken(): string | null {
    return localStorage.getItem('spotify_token');
  }

  /**
   * Remove o token do armazenamento local
   */
  static clearToken(): void {
    localStorage.removeItem('spotify_token');
  }
}
